function e(t){return{name:"Plain text",aliases:["text","txt"],disableAutodetect:!0}}export{e as default};
